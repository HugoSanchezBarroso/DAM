public class Calculadora {
    private int num1;
    private int num2;
    public Calculadora (int num1, int num2) {
        this.num1 = num1;
        this.num2 = num2;
    }

    public double sumar() {
        return num1 + num2;
    }

    public double restar() {
        return num1 - num2;
    }

    public double multiplicar() {
        return num1 * num2;
    }

    public double dividir() {
        try {
            return num1 / num2;
        } catch (ArithmeticException e) {
            System.out.println("Error: División por cero");
            return -1;
        }
    }
}
