import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CalculadoraTest {
    @Test
        void test() {
            Calculadora c = new Calculadora(7, 0);
            assertAll(
                    //() -> assertEquals(1, c.sumar())
                    //() -> assertEquals(0, c.restar())
                    //() -> assertEquals(12, c.multiplicar())
                    () -> assertEquals(2, c.dividir())
        );
    }
}
